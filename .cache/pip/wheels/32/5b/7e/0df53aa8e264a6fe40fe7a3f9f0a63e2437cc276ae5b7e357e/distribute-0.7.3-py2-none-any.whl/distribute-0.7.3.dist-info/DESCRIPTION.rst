Distribute - legacy package

This package is a simple compatibility layer that installs Setuptools 0.7+.


